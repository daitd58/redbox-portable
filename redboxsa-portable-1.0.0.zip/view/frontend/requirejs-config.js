/**
 * (c) Redbox Parcel Lockers <thamer@redboxsa.com>
 * This source file is subject to the license that is bundled
 * with this source code in the file LICENSE.
 *
 * Built by Redbox Technologies, <thamer@redboxsa.com>
 */

 var config = {
    config: {
        mixins: {
            'Magento_Ui/js/form/element/abstract': {
                'Redbox_Portable/js/form/mixin': true
            }
        }
    }
};